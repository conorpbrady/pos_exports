from lib.pointofsale import PointOfSale
from lib.infogenesisdatabase import InfogenesisDatabase


class Infogenesis(PointOfSale):
    

    def __init__():

        self.file_path = config['SalesFilePath']
        self.db_definition = config['DatabaseDefinitionFile']
        self.site_code = config['SiteCode']
        self.sql_query = ''
        self.query_path = config['QueryFilePath']
        self.results = []
        self.ig_db = InfogenesisDatabase('temp\\temp.db')

    def create_database():

        self.ig_db.init_queries()
        self.ig_db.create_tables()
        self.ig_db.insert_values()
        
    def gather_pos_data():
        self.get_files_from_zip()
        
        self.create_database()
        self.results = self.ig_db.query_database(super().load_query_from_file())

    def format_data():
        pass

    def clean_up():
        
        self.ig_db.close()
        # get dir listing of temp
        # use to remove


    def get_files_from_zip(self):
        date_string = self.business_date.strftime('%Y%m%d')
        full_file_path = '{}{}\\{}_{}.zip'.format(self.file_path,
                                                  self.site_code,
                                                  self.site_code,
                                                  date_string)
        
        with zipfile.ZipFile(full_file_path, 'r') as zip_read:
            for file in self.files_needed():
                zip_read.extract(file, path='temp\\')


    def files_needed(self):
        files = []
        with open(self.db_definition,'r') as r:
            csv_reader = csv.reader(r)
            for row in csv_reader:
                if row[0] not in files:
                    files.append(row[0])
        return files
        
                                            

                
                
